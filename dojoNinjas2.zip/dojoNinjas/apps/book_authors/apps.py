from __future__ import unicode_literals

from django.apps import AppConfig


class BookAuthorsConfig(AppConfig):
    name = 'book_authors'
