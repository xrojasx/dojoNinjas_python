from django.shortcuts import render
from apps.book_authors.models   import Book, Author
def index(request):
    context = {}
    return render(request, "book_authors/index.html")
